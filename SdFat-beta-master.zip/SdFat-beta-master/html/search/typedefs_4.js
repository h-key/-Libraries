var searchData=
[
  ['ldir_5ft',['ldir_t',['../_fat_structs_8h.html#aa1b540ee1eedd1aa9b267d11cba0d9e2',1,'FatStructs.h']]]
];
