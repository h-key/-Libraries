var searchData=
[
  ['software_20spi',['Software SPI',['../group__soft_s_p_i.html',1,'']]]
];
