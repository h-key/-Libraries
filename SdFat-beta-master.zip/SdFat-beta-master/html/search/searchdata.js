var indexSectionsWithContent =
{
  0: "_abcdefghijlmnoprstuvwy",
  1: "abcdfgilmops",
  2: "abdfios",
  3: "abcdefghilmnoprstuvwy",
  4: "_abcdefghijlmnoprstuvw",
  5: "bdfilmops",
  6: "s",
  7: "bce",
  8: "adefimnpsu",
  9: "fs",
  10: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

