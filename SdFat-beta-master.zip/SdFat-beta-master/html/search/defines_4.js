var searchData=
[
  ['implement_5fspi_5finterface_5fselection',['IMPLEMENT_SPI_INTERFACE_SELECTION',['../_sd_fat_config_8h.html#a84c504fb619d92d3af2e4445f4c004e1',1,'SdFatConfig.h']]],
  ['isdirseparator',['isDirSeparator',['../_fat_file_8h.html#a9f85580ad6f1dfc86fff09a58ff0a1c0',1,'FatFile.h']]]
];
