uint8_t validImage(uint8_t *base);
